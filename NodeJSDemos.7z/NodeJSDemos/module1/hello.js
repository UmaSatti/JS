// Module 1 Get Started on Node.js

// console.log('hello world\n');

var name = 'Aflred';
console.log(`Hello ${name}`);