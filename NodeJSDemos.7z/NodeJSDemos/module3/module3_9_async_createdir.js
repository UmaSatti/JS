var fs = require("fs");

fs.mkdir("lib2", (err) => {
	console.log("Directory Created");
	});

