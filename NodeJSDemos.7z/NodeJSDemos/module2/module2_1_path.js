// Module 2 Built in Modules
// Path Module

const path = require('path');

//basename and dirname
// console.log(path.basename('/test/demo1.txt'));
// console.log(path.dirname('/test/demo1.txt'));

//__filename and __dirname
console.log(path.basename(__filename)); //gives the filename
console.log( path.basename(__dirname)); // gives u the directory

// Join
let testdir = path.join(__dirname, 'test');
console.log(testdir);


